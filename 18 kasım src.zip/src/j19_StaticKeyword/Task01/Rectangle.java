package j19_StaticKeyword.Task01;

public class Rectangle {
    int width;
    int length;

    public int Cevre()
    {
        return (width+length)*2;
    }

    public int Alan()
    {
        return (width*length);
    }
}
