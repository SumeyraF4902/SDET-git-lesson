package j19_StaticKeyword.Task02;

public class Musteri {
    String name;
    ElektrikHesabi elektrikHesabi;
}
