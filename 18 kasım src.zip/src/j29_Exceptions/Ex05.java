package j29_Exceptions;

public class Ex05 {
    public static void main(String[] args) {
        // Aşağıdaki code output ne olur ?

        System.out.println(5/0);//ArithmeticException
        
    }
}
