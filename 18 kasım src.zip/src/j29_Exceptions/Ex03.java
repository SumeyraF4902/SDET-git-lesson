package j29_Exceptions;

public class Ex03 {
  // 7 ve 8. satır ... yerine ne gelmeli ?
   // public  void ohNo() throws Exception {
   //     throw new Exception();
        // public  void ohNo() .... Exception {
       // .... Exception();
    }
    // 7. satır -> fill in throws
    // 8. satır -> fill in throw new

//}
