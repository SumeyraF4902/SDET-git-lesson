package j29_Exceptions;

public class Task02 {
    public static void main(String[] args) {
         /*
    Task -> girilen hava sıcaklığı 10'un altında ise IOException hatası tanımlayıp hatayı print eden method create
    edip mainde kontrol ediniz.

    Trick->
    sicaklikKontrol(int sıcaklık){
     throw new IOException("Hava Gerçekten soğuk dışarı çıkma");

    }

    main(){
    Scanner ...
    try{
     sicaklikKontrol(int sıcaklık);
    }
    catch (IOException e) {
    }

    }
     */





    }// main sonu




}
