package j02_DataTypes_WrapperClass.tasks;

public class _17_create_char1 {

    public static void main(String[] args) {

    /*    a olan bir char oluşturun.
          Bu char'ı yazdırın.   */

        //Kodu aşağıya yazınız.




    }
}
