package j02_DataTypes_WrapperClass.tasks;

public class _16_create_short3 {

    public static void main(String[] args) {

    /*    Değeri -100 olan bir short oluşturun.
          Short'u yazdırın.   */

        //Kodu aşağıya yazınız.



    }
}
