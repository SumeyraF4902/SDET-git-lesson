package j02_DataTypes_WrapperClass.tasks;

public class _14_create_short1 {

    public static void main(String[] args) {

    /*    Değeri 12 olan bir short oluşturunuz.
          Short'u yazdırınız.  */

        //Kodu aşağıya yazınız.



    }
}
