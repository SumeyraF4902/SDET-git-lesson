package j02_DataTypes_WrapperClass.tasks;

public class _12_create_float2 {

    public static void main(String[] args) {

    /*    Değeri 123.3365f olan bir float oluşturunuz.
          Float'ı yazdırınız  */

        //Kodu aşağıya yazınız.




    }
}
