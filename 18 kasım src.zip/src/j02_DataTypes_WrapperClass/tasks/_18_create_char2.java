package j02_DataTypes_WrapperClass.tasks;

public class _18_create_char2 {

    public static void main(String[] args) {

    /*    z olan bir char oluşturun.
          Bu char'ı yazdırın.   */

        //Kodu aşağıya yazınız.


    }
}
