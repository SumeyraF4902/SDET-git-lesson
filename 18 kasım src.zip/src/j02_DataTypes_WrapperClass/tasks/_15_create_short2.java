package j02_DataTypes_WrapperClass.tasks;

public class _15_create_short2 {

    public static void main(String[] args) {

    /*    Değeri 23 olan bir short oluşturunuz.
          Short'u yazdırınız.  */

        //Kodu aşağıya yazınız.



    }
}
