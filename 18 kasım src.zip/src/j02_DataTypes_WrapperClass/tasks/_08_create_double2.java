package j02_DataTypes_WrapperClass.tasks;

public class _08_create_double2 {

    public static void main(String[] args) {

    /*    Değeri 120.005 olan bir double oluşturunuz.
          Double'ı yazdırınız. */

        //Kodu aşağıya yazınız.




    }
}
