package kahoot01;

public class Q07 {


    public static void main(String[] args) {


        int[][] x = {{3, 1, 4}, {1, 5, 9}};
        int[] y = {2, 6, 7};
        y = x[1];
        System.out.println(x[0][1] + x[1][1]);


    }
}
