package j18_Constructor;

public class C06_OgrcRunner {
    public static void main(String[] args) {
        C06_Ogrc tlb =new C06_Ogrc("Saliha H",21);
        System.out.println("tlb.isim = " + tlb.isim);//Saliha H
        System.out.println("tlb.yas = " + tlb.yas);//21
        System.out.println("tlb.age = " + tlb.age);//21
        System.out.println("tlb.name = " + tlb.name);//21
    }
}
