package j08_ifStatement_TernaryOperator;

public class Ex10 {
    public static void main(String[] args) {
     //  x = str(input("taş,kağıt,makas")).lower()
     //  y = str(input("taş,kağıt,makas")).lower()

     //  if x == y :
     //  print("berabere")
     //  else if x == "taş" and y== "kağıt":
     //  print("kazanan:y")
     //  else if x == "kağıt" and y == "taş":
     //  print("kazanan: x")
     //  else if x == "makas" and y=="kağıt":
     //  print("kazanan: x")
     //  else if y == "makas" and x== "kağıt":
     //  print("kazanan: y")
     //  else if y== "makas" and x=="taş":
     //  print("kazanan: x")
     //   else
     //  print("sizden istenen ifadelerden birini giriniz")
    }
}
