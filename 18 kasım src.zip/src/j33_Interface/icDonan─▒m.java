package j33_Interface;

public interface icDonanım {

   abstract void koltuk();// abs. meth-> public abstract
  public   void klima();// abs. meth

    static final String MUSIC="arizona kertenkele style :)underground";
  // String  kumas ;//final variable initial edilmeli CTE
    String  KUMAS="kadife";
    String  RENK="ahsap";
}
