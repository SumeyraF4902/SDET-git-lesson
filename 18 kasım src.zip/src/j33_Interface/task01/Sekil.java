package j33_Interface.task01;

public interface Sekil {
    double PI=3.14;//final static variable
    int cevre(int ... boyut);//varargs parametreli abs. meth-> impleee...
    int alan(int ...boyut);//varargs parametreli abs. meth-> impleee...
}
