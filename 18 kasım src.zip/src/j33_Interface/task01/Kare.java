package j33_Interface.task01;

public class Kare extends Dikdortgen{

}
