package j33_Interface;

public abstract class Tofas {//abs. parent Class

    public  abstract void motor();//abs. meth.
    public  abstract void yakıt();//abs. meth.
     public void sunroof(){//conc. meth
         System.out.println("agam güneşli havada sunroof açarsan bagrında maaşallah yazar :)");
     }

}
