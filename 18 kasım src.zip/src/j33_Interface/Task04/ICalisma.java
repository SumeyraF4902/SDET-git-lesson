package j33_Interface.Task04;

public interface ICalisma {

    void calis();


}
