package j33_Interface.Task05;

public interface IMuhendis {

    void askerlik_durumu_sorgula();

    String mezuniyet_ortalamasi(double derece);

    void adli_sicil_sorgulama();

    void is_tecrubesi(String[] array);

}
