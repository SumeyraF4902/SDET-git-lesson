package j33_Interface;

public interface Lastik {

    void ebat();//public abs. meth.

    public abstract void jant();//public abs. meth.

    String RENK="siyah beyazlı yanaklı";


}
