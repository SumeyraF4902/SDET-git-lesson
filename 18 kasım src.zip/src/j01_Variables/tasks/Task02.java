package j01_Variables.tasks;

public class Task02 {
    public static void main(String[] args) {
        /*
        TASK:
		 * Sadece System.out.println kullanarak bu işlemleri yapınız.
         *    Herhangi bir değişken kullanmayın.
         * 1. Adım : İsim ve Soyismiminizi ekrana yazdırın.
         * 2. Adım : Satır atlayarak boyunuzu ekrana yazdırın.
         * 3. Adım : Satır atlayarak kilonu ekrana yazdırın.
         * 4. Adım : Satır atlayarak hobilerinizi ekrana yazdırın.

	             OUTPUT :
	             Haluk Bilgin
	             190
	             99
	             Yuzme FUTBOL Java ...
		 */
        System.out.println("Ad Soyad : Haluk Bilgin\nBoy : 190\nKilo : 99\nHobiler : Yuzme FUTBOL Java ...");
        //System.out.println("Haluk Bilgin");
        //System.out.println("190");
        //System.out.println("99");
        //System.out.println("Yuzme FUTBOL Java ...");
    }
}
