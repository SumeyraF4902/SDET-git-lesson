package j22_DateTime.GirisProject;

public class Runner {
    public static void main(String[] args) {//mo-torrrr

        //GirisPaneli.giris(); //ClassName ile method call
        GirisPaneli grsObj=new GirisPaneli();
        grsObj.giris();//obj ile method call
       // new GirisPaneli().giris();//obj ile method call
    }
}
