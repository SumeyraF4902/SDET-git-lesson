package j32_Abstract.Ornek7;

public class FileMain {
    public static void main(String[] args) {
        TxtFile txtFile = new TxtFile();
        System.out.println(txtFile.close());
    }
}
