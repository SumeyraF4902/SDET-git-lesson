package j32_Abstract.Ornek7;

public interface ReadFile {
    public String open();

    public String read();

    public String save();

    public String close();

}
