package j32_Abstract.Ornek3;

public  abstract class Food {

    public abstract void madeIn();
    public  abstract void taste();

}
