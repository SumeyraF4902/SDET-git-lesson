package j32_Abstract.Ornek3;

public class Baklava extends Sweet {


    @Override
    public void madeIn() {
        System.out.println("agam baklava yerli ve milli hat-lis 27 ayar ayıntap malı");
    }
}
