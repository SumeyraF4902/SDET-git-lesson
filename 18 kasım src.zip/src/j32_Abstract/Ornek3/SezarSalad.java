package j32_Abstract.Ornek3;

public class SezarSalad extends Salad {
    @Override
    public void madeIn() {
        System.out.println("Agam sezar yemiş biz bakmışız çok da şeey etme \n İtaly ");
    }
}
