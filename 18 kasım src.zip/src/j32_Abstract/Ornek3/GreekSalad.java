package j32_Abstract.Ornek3;

public class GreekSalad extends Salad{
    @Override
    public void madeIn() {
        System.out.println("Agam Komşi rum salatası bi nevi gavur salatası ");
    }


}
