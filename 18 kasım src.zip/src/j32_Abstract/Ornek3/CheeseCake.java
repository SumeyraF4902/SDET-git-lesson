package j32_Abstract.Ornek3;

public class CheeseCake extends Sweet {
    @Override
    public void madeIn() {
        System.out.println("agam pynirden tatlılı olur USA malı ");
    }
}
