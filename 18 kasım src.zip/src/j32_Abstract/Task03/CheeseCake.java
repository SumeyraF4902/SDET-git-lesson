package j32_Abstract.Task03;

public class CheeseCake extends Sweet {
    @Override
    public void madeIn() {
        System.out.println("made in USA");
    }
}
