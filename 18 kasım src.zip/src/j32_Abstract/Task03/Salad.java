package j32_Abstract.Task03;

public abstract class Salad extends Food {
    @Override
    public void taste() {
        System.out.println("sirkeli, limonlu, sumaklı...");
    }
}
