package j32_Abstract.Task03;

public class SezarSalad extends Salad {
    @Override
    public void madeIn() {
        System.out.println("made in İTALY");
    }
}
