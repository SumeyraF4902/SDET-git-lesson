package j32_Abstract.Task03;

public abstract class Sweet extends Food {

    @Override
    public void taste() {
        System.out.println("tatli, iyi,  şekerli,...");

    }
}
