package j32_Abstract.Task03;

public class Baklava extends Sweet {
    @Override
    public void madeIn() {
        System.out.println("yerli ve milli baklava...");
    }
}
