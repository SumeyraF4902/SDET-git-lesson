package j32_Abstract.Ornek8;

public class Cat implements Animal {

    @Override
    public String food() {
        return "mama";
    }
}
