package j32_Abstract.Ornek8;

public class Swallow implements Flying {
    @Override
    public String food() {
        return "Hamsi";
    }
}
