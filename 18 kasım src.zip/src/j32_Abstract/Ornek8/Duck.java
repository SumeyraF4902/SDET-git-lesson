package j32_Abstract.Ornek8;

public class Duck implements Sailling {

    @Override
    public String food() {
        return "balık";
    }
}
