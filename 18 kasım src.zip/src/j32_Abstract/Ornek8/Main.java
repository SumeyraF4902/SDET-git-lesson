package j32_Abstract.Ornek8;

public class Main {
    public static void main(String[] args) {
        Swallow swallow = new Swallow();
        System.out.println(swallow.food());
    }
}
