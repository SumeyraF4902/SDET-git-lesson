package j32_Abstract.Ornek8;

public interface Sailling extends Animal {

}
