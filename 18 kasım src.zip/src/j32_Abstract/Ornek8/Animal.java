package j32_Abstract.Ornek8;

public interface Animal {
    String food();
}
