package j32_Abstract.Ornek5;

public abstract interface IFood {
    void taste();

    double ucret();
}
