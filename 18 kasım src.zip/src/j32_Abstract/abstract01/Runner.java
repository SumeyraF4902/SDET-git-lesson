package j32_Abstract.abstract01;

public class Runner {
    public static void main(String[] args) {
        Civic cvc = new Civic();
        cvc.sunrooff();
        cvc.vites();
        cvc.lastikEbat();
        cvc.motor();
        cvc.kapı();
        cvc.koltuk();

    }
}
