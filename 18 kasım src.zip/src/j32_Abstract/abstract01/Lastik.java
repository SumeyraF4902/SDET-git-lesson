package j32_Abstract.abstract01;

public abstract class  Lastik extends Honda{



    public  abstract  void lastikEbat();//abs method


    public void kısLastik(){//concerete method
        System.out.println("agam pis cezası var ihmal etme :)");
    }
}
