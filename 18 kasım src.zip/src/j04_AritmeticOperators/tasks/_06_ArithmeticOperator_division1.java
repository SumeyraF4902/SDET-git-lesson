package j04_AritmeticOperators.tasks;

import java.util.Scanner;

public class _06_ArithmeticOperator_division1 {

    public static void main(String[] args) {

        /*     kullanıcıdan alınan iki tane int  (num1 , num2),
         bölümünü print eden code create ediniz.   */


    }
}
