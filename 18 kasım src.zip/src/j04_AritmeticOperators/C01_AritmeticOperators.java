package j04_AritmeticOperators;

public class C01_AritmeticOperators {
    public static void main(String[] args) {


        int a = 13;
        int b = 17;
        int c = 47;

        System.out.println(b+a*c);//628
        System.out.println(c-a/(b-c)+a*b);//268

        int g=2;
        int h=3;
        String  s="JavaCAN";
        //Task-> g h s variable'ları kullanarak 61JavaCAN-1 print eden code create ediniz.


        System.out.println(""+(g*h)+(h-g)+s+(g-h));//61JavaCAN-1












    }
}
