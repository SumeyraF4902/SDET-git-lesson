package j26_Inheritance.task01;

public class A {
  static   String  mesaj="Agam'a A class'dan hörmetler :)";

}
