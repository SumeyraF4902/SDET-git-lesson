package j26_Inheritance.task01;

public class B extends A  {
    public B() {
        mesaj="static variable inheritance'da ClassNAme olmadan call edilir";
    }
}
