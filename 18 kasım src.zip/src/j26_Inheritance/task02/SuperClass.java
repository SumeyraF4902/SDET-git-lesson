package j26_Inheritance.task02;

public class SuperClass {

    int num  = 20;
    public  void goster(){
        System.out.println("Bu method süper classsın görüntülenme methodudur. ");
    }
}
