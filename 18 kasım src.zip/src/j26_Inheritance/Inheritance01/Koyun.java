package j26_Inheritance.Inheritance01;

public class Koyun extends Mammal{//Mammal parent class Koyun child class-< torun

    public  void semir(){
        System.out.println("AGAM goyunung en lezzetli yeri küşleme ve böbrek yatagı :)");
    }
}
