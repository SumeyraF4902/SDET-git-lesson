package j26_Inheritance.Inheritance01;

public class Hayvancık {//G parent-super-dede class

  public Hayvancık() {//p'siz cons.

     System.out.println("Agam ahan da HAYVANCIK p'siz cons...");
  }
    public void hareket() {
        System.out.println(" HAYVANCIK  hareket eder...");
    }
    public void yeme() {
        System.out.println(" HAYVANCIK  fena yer ...");
    }
    public void içme() {
        System.out.println(" HAYVANCIK  pis içer ...");
    }

}
