package j26_Inheritance.Inheritance01;

public class Paluk extends Hayvancık{
    public  void ızgaraTava (){
        System.out.println("AGAM şimdi palamut 1-2 hafta sonra çinekop sarıkanat lüfer kofana yenir\npalug'un kiralu somon kalkan kılıç");
    }


}
