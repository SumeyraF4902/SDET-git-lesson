package j13_Break_Continue;

import java.util.Scanner;

public class C05_Task02 {
    public static void main(String[] args) {
        // Task-> girilen 7 tamsyının 10 ile 20 arasındakileri hariç toplamını print eden code create ediniz.


    }
}
