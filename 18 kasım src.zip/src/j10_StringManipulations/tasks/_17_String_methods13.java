package j10_StringManipulations.tasks;

public class _17_String_methods13 {

    public static void main(String[] args) {

        /*  Thank you olan bir String oluşturun.
            Thank you içindeki, sadece  'y' harfinin bulunduğu konumu yazdırın.
            // Thank you Stringini oluşturun.  */

        //Kodu aşağıya yazınız.


    }
}
