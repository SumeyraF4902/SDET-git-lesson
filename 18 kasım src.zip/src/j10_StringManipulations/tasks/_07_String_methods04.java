package j10_StringManipulations.tasks;

public class _07_String_methods04 {

    public static void main(String[] args) {

        /* OraNge olan bir String oluşturun.
           String'i küçük harfe çevirin ve yazdırın.
           örn: APPLE > apple  */

        //Kodu aşağıya yazınız.




    }
}
