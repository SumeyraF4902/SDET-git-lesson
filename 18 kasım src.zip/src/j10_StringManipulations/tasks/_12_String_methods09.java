package j10_StringManipulations.tasks;

public class _12_String_methods09 {

    public static void main(String[] args) {

        /*  apple kelimesinden  oluşan bir String yaz.
            String'in içinde App olup olmadığını doğrula.  */

        //Kodu buraya yazınız.


    }
}
