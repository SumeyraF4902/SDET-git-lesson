package j10_StringManipulations.tasks;

public class _08_String_methods05 {

    public static void main(String[] args) {

        /*  New Jersey olan bir String oluşturun.
        String'i büyük harfe çevirin ve yazdırın  */

        //Kodu aşağıya yazınız.



    }

}
