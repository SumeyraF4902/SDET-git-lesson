package j10_StringManipulations.tasks;

public class _04_String_methods01 {

    public static void main(String[] args) {

        /*  I love java olan bir String oluşturun.
            Bu cümlenin toplam karakter sayısını yazdırın.   */

        //Kodu aşağıya yazınız.




    }
}
