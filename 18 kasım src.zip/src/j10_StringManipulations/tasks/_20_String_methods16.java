package j10_StringManipulations.tasks;

public class _20_String_methods16 {

    public static void main(String[] args) {

        /*  String s1 = "    Chocolade     ";
            s1 String'inin başındaki ve sonundaki boşlukları kaldırın.
            s1 String'ini yazdırın.  */

        //Kodu buraya yazınız.




    }
}
