package j10_StringManipulations.tasks;

public class _13_String_methods10 {

    public static void main(String[] args) {

        /*  orange kelimesinden oluşan bir String oluşturun.
            String'in Apple'a eşit olup olmadığını doğrulayın. */

        //Kodu aşağıya yazınız.


    }
}
