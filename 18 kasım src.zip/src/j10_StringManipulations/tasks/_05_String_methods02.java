package j10_StringManipulations.tasks;

public class _05_String_methods02 {

    public static void main(String[] args) {

    /*    Sprint planning olan bir String oluşturun.
        Bu dizenin toplam karakter sayısını yazdırın.   */

        //Kodu aşağıya yazınız.


    }
}
