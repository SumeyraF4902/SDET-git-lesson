package j10_StringManipulations.tasks;

public class _19_String_methods15 {

    public static void main(String[] args) {

        /* Main method oluşturun.
            Mouse değerinde bir String oluştur.
            Mouse String'inin 2. sırasındaki karakteri yazdırın.  */

        //Kodu buraya yazınız.




    }
}
