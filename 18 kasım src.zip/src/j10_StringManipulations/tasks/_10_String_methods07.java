package j10_StringManipulations.tasks;

public class _10_String_methods07 {

    public static void main(String[] args) {

        /*  PADDLE olan bir String oluşturun.
            String'i küçük harfe çevirin ve yazdırın.  */

        //Kodu aşağıya yazınız.


    }
}
