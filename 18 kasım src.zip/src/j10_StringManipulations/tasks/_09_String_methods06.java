package j10_StringManipulations.tasks;

public class _09_String_methods06 {

    public static void main(String[] args) {

        /*  New York olan bir String oluşturun.
            String'i küçük harfe çevirin ve yazdırın.  */

        //Kodu aşağıya yazınız.


    }
}
