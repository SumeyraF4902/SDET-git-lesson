package j10_StringManipulations.tasks;

public class _11_String_methods08 {

    public static void main(String[] args) {

        /*  apple olan bir String oluşturun.
            String'in içinde app olup olmadığını doğrula.   */

        //Kodu aşağıya yazınız.




    }
}
