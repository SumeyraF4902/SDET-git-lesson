package j10_StringManipulations.tasks;

public class _18_String_methods14 {

    public static void main(String[] args) {

        /*  String s1 = "      Clarus  Way          ";
            s1 String'inin önündeki ve arkasındaki boşlukları kaldırın.
            s1 String'ini yazdırın.  */

        //Kodu aşağıya yazınız.





    }
}
