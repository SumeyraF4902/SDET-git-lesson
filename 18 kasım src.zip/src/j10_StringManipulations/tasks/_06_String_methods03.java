package j10_StringManipulations.tasks;

public class _06_String_methods03 {

    public static void main(String[] args) {

    /*    paper olan bir String oluşturun.
          String'i büyük harfe çevirin ve yazdırın.
          örn: apple > APPLE   */

        //Kodu aşağıya yazınız.

    }
}
