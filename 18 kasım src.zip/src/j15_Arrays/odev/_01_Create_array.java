package j15_Arrays.odev;

public class _01_Create_array {

    public static void main(String[] args) {
        /*
        Task ->
        elemanları : Apple, Orange , Banana, Kiwi
        olan String Array (Dizi) crdeate edip print eden code create ediniz.

         */

        //Kodu aşağıya yazınız.


    }
}
