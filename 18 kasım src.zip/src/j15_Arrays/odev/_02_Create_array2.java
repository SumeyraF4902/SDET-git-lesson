package j15_Arrays.odev;

public class _02_Create_array2 {

    public static void main(String[] args) {

    /*          int Array oluşturun.
                elemanları : 13, 15,14,16,16
                Arrayin elemanlarını yazdırın.
     */
        // Kodu aşağıya yazınız..


    }
}
